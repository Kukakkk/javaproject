package com.company;

public abstract class Person { //declaring an abstract class Person which has Customer and Employee child classes
    private int id;
    private String fname;
    private String lname;
    private String position;
    private double sumOfPurchases;
    private String books_name;
    private int books_number;
    //Encapsulation
    public int getBooks_number() {
        return books_number;
    }

    public void setBooks_number(int books_number) {
        this.books_number = books_number;
    }

    public String getBooks_name() {
        return books_name;
    }

    public void setBooks_name(String books_name) {
        this.books_name = books_name;
    }

    public double getSumOfPurchases() {
        return sumOfPurchases;
    }

    public void setSumOfPurchases(double sumOfPurchases) {
        this.sumOfPurchases = sumOfPurchases;
    }

    public String getFname() {
        return fname;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //declaring an abstract function which will be inherited by customer and employee classes
    public abstract void outputData();



}

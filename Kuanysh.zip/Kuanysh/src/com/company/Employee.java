package com.company;

public class Employee extends Person{
    @Override //overriding the method outputData for customer
    public void outputData(){
        System.out.println("The employees has a 15% discount for all products");
        System.out.println("The employee " + getLname() + " " + getFname() + " bought " + getBooks_number() +
                " books called " +  getBooks_name() + " for " + getSumOfPurchases()*0.85);
    }
}

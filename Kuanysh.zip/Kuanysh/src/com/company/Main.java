package com.company;

import org.postgresql.util.PSQLException;

import java.sql.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in); //declaring a scanner which allows us to input from keyboard
        try{
            Class.forName("org.postgresql.Driver"); //connecting a driver to Java project
            //connecting to postgresql
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Library", "postgres", "pass");
            System.out.println("What do you want to do?");//Outputting informational labels
            System.out.println("Add new books to library - 1");
            System.out.println("Customer buys a book - 2");
            System.out.println("Employee buys a book - 3");
            System.out.println("Refill existing books - 4");
            System.out.println("Show the customer's purchases - 5");
            System.out.println("Show the employee's purchases - 6");
            int a = cin.nextInt(); //inputting a by using keyboard
            if(a==1) { //all below for function 1
                try {
                    boolean work = true; //declaring a new variable
                    //setting a new statement to Insert the data to database
                    PreparedStatement stmt = con.prepareStatement("INSERT INTO public.library(\n" +
                            "\tbooks_id, books_name, \"number\", books_price)\n" +
                            "\tVALUES (?, ?, ?, ?);");
                    while(work) { //while work is true, the loop never won't stop
                        System.out.println("Input the id of book"); //outputting informational label
                        int id = cin.nextInt();//inputting id from keyboard
                        System.out.println("Input the numbers of book");//outputting informational label
                        int numbers = cin.nextInt();//inputting numbers from keyboard
                        System.out.println("Input the price of book");//outputting informational label
                        int price = cin.nextInt();//inputting price from keyboard
                        System.out.println("Input the name of book");//outputting informational label
                        String name = cin.next();//inputting name from keyboard
                        stmt.setInt(1, id); //setting data on statement above
                        stmt.setString(2, name);
                        stmt.setInt(3, numbers);
                        stmt.setInt(4, price);
                        stmt.executeUpdate(); //executing the statement, which means the inserting the data to database
                        System.out.println("Do you want to add another book?\nYes - 1\nNo - 2");
                        int y = cin.nextInt(); //inputting y from keyboard
                        if(y!=1)work=false; //if y doesn't equal to 1, which means that it's not necessary to add another book
                    }
                    stmt.close(); //closing the statement
                } catch (PSQLException e) { //this exception means the same of primary key variables
                    System.out.println("This id isn't available!");//if the exception runs, it outputs this text
                }finally //means that it will runs anyway
                 {
                     System.out.println("Success!");
                    con.close(); //closing the connection
                }
            }
            if(a==2){ //all below for function 2
                try{
                    //setting a new statement to Insert the data to database
                    PreparedStatement stmt = con.prepareStatement("INSERT INTO public.person(\n" +
                            "\tid, fname, lname, \"position\")\n" +
                            "\tVALUES (?, ?, ?, ?);");
                    System.out.println("Input the id of customer");  //output the informational labels
                    int id= cin.nextInt(); //inputting the id from keyboard
                    stmt.setInt(1, id); //setting the data on statement
                    System.out.println("Input the first name of customer");
                    stmt.setString(2, cin.next());
                    System.out.println("Input the second name of customer");
                    stmt.setString(3, cin.next());
                    stmt.setString(4, "Customer");
                    stmt.executeUpdate(); //inserting the statement to database
                    stmt.close(); //closing the statement
                    //declaring a new statement to insert data
                    PreparedStatement stmt2 = con.prepareStatement("INSERT INTO public.person_buy(\n" +
                            "\tperson_id, books_id, number_of_books)\n" +
                            "\tVALUES (?, ?, ?);");
                    stmt2.setInt(1, id);//setting data on statement
                    System.out.println("Input the id of book"); //outputting informational text
                    int book_id = cin.nextInt(); //inputting book_id from keyboard
                    stmt2.setInt(2, book_id);
                    System.out.println("Input the numbers of book");
                    int numbers = cin.nextInt();
                    stmt2.setInt(3, numbers);
                    stmt2.executeUpdate(); //inserting the statement and data to db
                    stmt2.close(); //closing the statement

                    //declaring a new statement select for SELECTing data from DB
                    Statement select = con.createStatement();
                    //creating a query
                    ResultSet rs = select.executeQuery("SELECT books_id, books_name, \"number\", books_price\n" +
                            "\tFROM public.library");
                    int total=0; //adding new variable
                    while(rs.next()){ //while the data strings is not null, it will run
                        //in this loop we are checking a concrete data with book id which same to our variable
                        if(rs.getInt("books_id")==book_id){ //if it's same, then we will get the number of books
                            total = rs.getInt("number");
                        }
                    }
                    select.close();

                    //declaring a new statement update to update the existing data in db
                    PreparedStatement update = con.prepareStatement("UPDATE public.library\n" +
                            "\tSET \"number\"=?\n" +
                            "\tWHERE books_id=" + book_id);
                    update.setInt(1, total-numbers); //we are decreasing the number of books, which depends on purchases
                    update.executeUpdate();//executing statement to insert data to db
                    update.close();
                }catch (PSQLException e ){
                    e.printStackTrace();
                }finally {
                    System.out.println("Success!");
                    con.close();
                }
            }
            if(a==3){
                try{
                    //declaring a new statement to insert the data to db
                    PreparedStatement stmt = con.prepareStatement("INSERT INTO public.person(\n" +
                            "\tid, fname, lname, \"position\")\n" +
                            "\tVALUES (?, ?, ?, ?);");
                    System.out.println("Input the id of employee"); //informational labels
                    int id= cin.nextInt(); //inputting id by using keyboard
                    stmt.setInt(1, id); //setting data on statement
                    System.out.println("Input the first name of employee");
                    stmt.setString(2, cin.next());
                    System.out.println("Input the second name of employee");
                    stmt.setString(3, cin.next());
                    stmt.setString(4, "Employee");
                    stmt.executeUpdate();
                    stmt.close(); //closing statement
                    //declation a new statement to insert the data to db
                    PreparedStatement stmt2 = con.prepareStatement("INSERT INTO public.person_buy(\n" +
                            "\tperson_id, books_id, number_of_books)\n" +
                            "\tVALUES (?, ?, ?);");
                    stmt2.setInt(1, id); //setting the data on statement and inputting data
                    System.out.println("Input the id of book");
                    int book_id = cin.nextInt();
                    stmt2.setInt(2, book_id);
                    System.out.println("Input the numbers of book");
                    int numbers = cin.nextInt();
                    stmt2.setInt(3, numbers);
                    stmt2.executeUpdate();//executing the statement
                    stmt2.close();

                    //declaring a new statement to SELECT the data from db
                    Statement select = con.createStatement();
                    ResultSet rs = select.executeQuery("SELECT books_id, books_name, \"number\", books_price\n" +
                            "\tFROM public.library");
                    int total=0; //creating a new variable
                    while(rs.next()){ //this loop is to match the data and find the exact value of some book
                        if(rs.getInt("books_id")==book_id){
                            total = rs.getInt("number");
                        }
                    }
                    select.close();

                    PreparedStatement update = con.prepareStatement("UPDATE public.library\n" +
                            "\tSET \"number\"=?\n" +
                            "\tWHERE books_id=" + book_id);
                    update.setInt(1, total-numbers);
                    update.executeUpdate();
                    update.close();
                }catch (PSQLException e){
                    e.printStackTrace();
                }finally {
                    System.out.println("Success!");
                    con.close();
                }
            }
            if(a==4){
                try{
                    //outputting informational label and inputting if of book
                    System.out.println("Input the id of book");
                    int book_id = cin.nextInt();
                    int total=0;
                    //declaring a new statement for selectind data from db
                    Statement select = con.createStatement();
                    ResultSet rs = select.executeQuery("SELECT books_id, books_name, \"number\", books_price\n" +
                            "\tFROM public.library");
                    while(rs.next()){//this loop is to match the data in db and find the exact value of some book
                        if(rs.getInt("books_id")==book_id){
                            total = rs.getInt("number");
                        }
                    }
                    rs.close(); select.close(); //closing the result set and statement
                    //informational label
                    System.out.println("Input the numbers of received books");
                    int numbers = cin.nextInt();
                    //declaring a new statement to update the data in db
                    PreparedStatement update = con.prepareStatement("UPDATE public.library\n" +
                            "\tSET \"number\"=?\n" +
                            "\tWHERE books_id=" + book_id);
                    update.setInt(1, total+numbers); //setting the numbers of exact book
                    update.executeUpdate();
                    update.close();
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    System.out.println("Success!");
                    con.close();
                }
            }
            if(a==5){
                //declaring a new statement for SELECT query
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT id, fname, lname, person_buy.number_of_books, books_name, books_price\n" +
                        "                        FROM public.person\n" +
                        "                        join person_buy\n" +
                        "                        on id = person_buy.person_id\n" +
                        "                       join library\n" +
                        "                        on library.books_id = person_buy.books_id\n" +
                        "\t\t\t\t\t\twhere position = 'Customer'");
                while(rs.next()){ //while the lines of data in not null, loop will run
                    Customer customer = new Customer(); //creating a customer by customer class
                    customer.setId(rs.getInt("id")); //setting the data from database to object
                    customer.setFname(rs.getString("fname"));
                    customer.setLname(rs.getString("lname"));
                    customer.setBooks_name(rs.getString("books_name"));
                    customer.setBooks_number(rs.getInt("number_of_books"));
                    customer.setPosition("Customer");//
                    int g = rs.getInt("number_of_books"); //declaring a new variables to calculate the sum purchases
                    int s = rs.getInt("books_price");
                    customer.setSumOfPurchases(g*s);
                    customer.outputData();// outputting data by using method in inherinted classes
                }
                rs.close();//closing result ser and statements
                stmt.close();
            }
            if(a==6){
                //declaring a new statement for SELECT
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT id, fname, lname, person_buy.number_of_books, books_name, books_price\n" +
                        "                        FROM public.person\n" +
                        "                        join person_buy\n" +
                        "                        on id = person_buy.person_id\n" +
                        "                       join library\n" +
                        "                        on library.books_id = person_buy.books_id\n" +
                        "\t\t\t\t\t\twhere position = 'Employee'");
                while(rs.next()){ //while the lines of data in not null, the loop will continue the creating
                    Employee employee = new Employee(); //a new object Employee from class Employee
                    employee.setId(rs.getInt("id")); //Setting the data of employee
                    employee.setFname(rs.getString("fname"));
                    employee.setLname(rs.getString("lname"));
                    employee.setBooks_name(rs.getString("books_name"));
                    employee.setBooks_number(rs.getInt("number_of_books"));
                    employee.setPosition("Employee");
                    int g = rs.getInt("number_of_books");
                    int s = rs.getInt("books_price");
                    employee.setSumOfPurchases(g*s);
                    employee.outputData();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}

package com.company;

public class Customer extends Person{
    @Override //overriding the method outputData for customer
    public void outputData(){
        System.out.println("The customer " + getLname() + " " + getFname() + " bought " + getBooks_number() +
                " books called " +  getBooks_name() + " for " + getSumOfPurchases());
    }
}
